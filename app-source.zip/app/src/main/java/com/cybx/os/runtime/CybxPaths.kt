package com.cybx.os.runtime

import android.content.Context
import java.io.File

class CybxPaths(context: Context) {
    val base = File(context.filesDir, "cybx").apply { mkdirs() }
    val rootfs = File(base, "rootfs")
    val downloads = File(base, "downloads").apply { mkdirs() }
    val bin = File(base, "bin").apply { mkdirs() }
    val logs = File(base, "logs").apply { mkdirs() }
    val rootfsArchive = File(downloads, "cybx-kali-arm64-rootfs.tar.xz")
}
