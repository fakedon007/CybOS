package com.cybx.os.runtime

import android.system.Os
import org.apache.commons.compress.compressors.xz.XZCompressorInputStream
import org.apache.commons.compress.archivers.tar.TarArchiveInputStream
import java.io.BufferedInputStream
import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream
import java.io.IOException
import java.nio.file.Files
import java.nio.file.Path

/**
 * Extracts a tar.xz rootfs into an app-private directory.
 * Rejects path traversal, absolute paths, escaping symlinks and hardlinks.
 * Special device/socket entries are ignored; Android cannot provide a normal Linux /dev.
 */
class SafeRootfsExtractor {
    fun extractTarXz(archive: File, destination: File, onEntry: (String) -> Unit = {}) {
        require(archive.isFile && archive.length() > 0) { "Rootfs archive is missing or empty" }
        val root = destination.canonicalFile
        if (root.exists()) root.deleteRecursively()
        check(root.mkdirs()) { "Could not create rootfs directory" }
        val rootPath = root.toPath()

        FileInputStream(archive).use { fis ->
            BufferedInputStream(fis).use { buffered ->
                XZCompressorInputStream(buffered).use { xz ->
                    TarArchiveInputStream(xz).use { tar ->
                        while (true) {
                            val entry = tar.nextTarEntry ?: break
                            val name = entry.name
                            val target = safeTarget(rootPath, name)
                            val parentCanonical = target.parent.toFile().canonicalFile.toPath()
                            if (!parentCanonical.startsWith(rootPath)) {
                                throw IOException("Archive entry traverses an existing symlink: $name")
                            }
                            onEntry(name)
                            when {
                                entry.isDirectory -> {
                                    Files.createDirectories(target)
                                    applyMode(target.toFile(), entry.mode)
                                }
                                entry.isSymbolicLink -> {
                                    val link = entry.linkName
                                    val linkFile = File(target.parent.toFile(), link)
                                    val resolved = linkFile.canonicalFile.toPath()
                                    if (!resolved.startsWith(rootPath)) {
                                        throw IOException("Symlink escapes rootfs: $name -> $link")
                                    }
                                    Files.createDirectories(target.parent)
                                    try { Files.deleteIfExists(target) } catch (_: Exception) {}
                                    Os.symlink(link, target.toString())
                                }
                                entry.isFile -> {
                                    Files.createDirectories(target.parent)
                                    Files.newOutputStream(target).use { out ->
                                        var remaining = entry.size
                                        val buffer = ByteArray(64 * 1024)
                                        while (remaining > 0) {
                                            val count = tar.read(buffer, 0, minOf(buffer.size.toLong(), remaining).toInt())
                                            if (count < 0) throw IOException("Truncated archive entry: $name")
                                            out.write(buffer, 0, count)
                                            remaining -= count
                                        }
                                    }
                                    applyMode(target.toFile(), entry.mode)
                                }
                                entry.isLink -> throw IOException("Hard links are not accepted in this installer: $name")
                                else -> {
                                    // Skip device nodes, FIFOs and other special entries.
                                }
                            }
                        }
                    }
                }
            }
        }
        // Runtime-owned directories are created explicitly for Android's restricted environment.
        listOf("dev", "proc", "sys", "tmp", "root", "run").forEach {
            File(root, it).mkdirs()
        }
    }

    private fun safeTarget(root: Path, rawName: String): Path {
        if (rawName.startsWith("/") || rawName.contains('\u0000')) {
            throw IOException("Absolute or invalid archive path: $rawName")
        }
        val normalized = root.resolve(rawName).normalize()
        if (!normalized.startsWith(root)) throw IOException("Archive path traversal: $rawName")
        return normalized
    }

    private fun applyMode(file: File, mode: Int) {
        // Preserve the archive's ordinary permission bits (setuid/setgid/sticky are stripped).
        Os.chmod(file.absolutePath, mode and 0x1FF)
    }
}
