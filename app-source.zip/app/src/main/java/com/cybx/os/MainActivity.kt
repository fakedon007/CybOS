package com.cybx.os

import android.net.Uri
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.cybx.os.runtime.CybxPaths
import com.cybx.os.runtime.LocalRuntimeInstaller
import com.cybx.os.runtime.ProotAdapter
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.BufferedReader
import java.io.InputStreamReader

private val Bg = Color(0xFF080D0B)
private val Panel = Color(0xFF111A16)
private val Green = Color(0xFF72F59A)
private val Muted = Color(0xFF9AB0A1)
private val Amber = Color(0xFFFFC66D)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { CybXApp() }
    }
}

private enum class Page(val title: String) {
    DASHBOARD("Dashboard"), INSTALL("Linux Setup"), TERMINAL("Terminal"),
    TOOLS("Tools"), FILES("Files"), SETTINGS("Settings")
}

@Composable
fun CybXApp() {
    val context = androidx.compose.ui.platform.LocalContext.current
    val paths = remember { CybxPaths(context) }
    val installer = remember { LocalRuntimeInstaller(context) }
    var page by remember { mutableStateOf(Page.DASHBOARD) }
    var refresh by remember { mutableIntStateOf(0) }
    var statusMessage by remember { mutableStateOf("CybX Mobile ready") }
    var busy by remember { mutableStateOf(false) }
    var sha256 by remember { mutableStateOf("") }
    val scope = rememberCoroutineScope()
    var terminalText by remember { mutableStateOf("CybX Terminal · Mobile rootless runtime\nLinux environment is not installed yet.\n") }
    var command by remember { mutableStateOf("") }
    var shellProcess by remember { mutableStateOf<Process?>(null) }
    var shellReady by remember { mutableStateOf(false) }

    val prootPicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri: Uri? ->
        if (uri != null) scope.launch {
            busy = true; statusMessage = "Checking ARM64 PRoot binary…"
            try {
                val installed = installer.importProot(uri)
                statusMessage = "PRoot imported: ${installed.name}"
                refresh++
            } catch (e: Exception) { statusMessage = e.message ?: "PRoot import failed" }
            finally { busy = false }
        }
    }
    val rootfsPicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri: Uri? ->
        if (uri != null) scope.launch {
            busy = true
            try {
                installer.importRootfs(uri, sha256) { statusMessage = it }
                statusMessage = "CybX Linux rootfs installed"
                refresh++
            } catch (e: Exception) { statusMessage = e.message ?: "Rootfs import failed" }
            finally { busy = false }
        }
    }

    val prootAvailable = remember(refresh) { ProotAdapter(paths).isAvailable() }
    val rootfsAvailable = remember(refresh) { paths.rootfs.resolve("etc/os-release").isFile }
    val runtimeReady = prootAvailable && rootfsAvailable

    MaterialTheme(colorScheme = darkColorScheme(
        primary = Green, background = Bg, surface = Panel,
        onBackground = Color.White, onSurface = Color.White,
        secondary = Amber
    )) {
        Scaffold(
            containerColor = Bg,
            topBar = {
                Column(Modifier.fillMaxWidth().background(Color(0xFF0B120F)).padding(horizontal = 18.dp, vertical = 12.dp)) {
                    Text("CYBX OS", color = Green, fontSize = 11.sp, fontWeight = FontWeight.Black, letterSpacing = 3.sp)
                    Text(page.title, color = Color.White, fontSize = 23.sp, fontWeight = FontWeight.Bold)
                }
            },
            bottomBar = {
                NavigationBar(containerColor = Color(0xFF0B120F), tonalElevation = 0.dp) {
                    val entries = listOf(Page.DASHBOARD, Page.INSTALL, Page.TERMINAL, Page.TOOLS, Page.FILES, Page.SETTINGS)
                    entries.forEach { item ->
                        NavigationBarItem(
                            selected = page == item, onClick = { page = item },
                            icon = { Icon(when(item) {
                                Page.DASHBOARD -> Icons.Default.Dashboard
                                Page.INSTALL -> Icons.Default.Download
                                Page.TERMINAL -> Icons.Default.Terminal
                                Page.TOOLS -> Icons.Default.Build
                                Page.FILES -> Icons.Default.Folder
                                else -> Icons.Default.Settings
                            }, contentDescription = item.title) },
                            label = { Text(item.title, fontSize = 9.sp) },
                            colors = NavigationBarItemDefaults.colors(selectedIconColor = Green, selectedTextColor = Green)
                        )
                    }
                }
            }
        ) { padding ->
            Column(Modifier.fillMaxSize().padding(padding).padding(horizontal = 16.dp, vertical = 12.dp)) {
                when (page) {
                    Page.DASHBOARD -> DashboardPage(runtimeReady, prootAvailable, rootfsAvailable, statusMessage,
                        onSetup = { page = Page.INSTALL }, onTerminal = { page = Page.TERMINAL })
                    Page.INSTALL -> InstallPage(
                        prootAvailable, rootfsAvailable, sha256, { sha256 = it }, busy, statusMessage,
                        onPickProot = { prootPicker.launch(arrayOf("*/*")) },
                        onPickRootfs = { rootfsPicker.launch(arrayOf("application/x-xz", "application/octet-stream", "*/*")) }
                    )
                    Page.TERMINAL -> TerminalPage(
                        ready = runtimeReady, text = terminalText, command = command,
                        onCommand = { command = it },
                        onRun = {
                            val cmd = command.trim()
                            if (cmd.isNotEmpty() && runtimeReady && !busy) {
                                busy = true
                                terminalText += "\ncybx@cybx:~$ $cmd\n"
                                command = ""
                                scope.launch {
                                    try {
                                        val result = withContext(Dispatchers.IO) {
                                            val p = ProotAdapter(paths).buildShellCommand(cmd)
                                            val proc = ProcessBuilder(p).directory(paths.rootfs).redirectErrorStream(true).start()
                                            val output = proc.inputStream.bufferedReader().readText()
                                            val code = proc.waitFor()
                                            output to code
                                        }
                                        terminalText += result.first + "\n[exit ${result.second}]\n"
                                    } catch (e: Exception) { terminalText += "Error: ${e.message}\n" }
                                    finally { busy = false }
                                }
                            }
                        },
                        busy = busy
                    )
                    Page.TOOLS -> ToolsPage(runtimeReady)
                    Page.FILES -> FilesPage(paths.rootfs, runtimeReady)
                    Page.SETTINGS -> SettingsPage(statusMessage)
                }
            }
        }
    }
}

@Composable
private fun DashboardPage(ready: Boolean, proot: Boolean, rootfs: Boolean, status: String,
                         onSetup: () -> Unit, onTerminal: () -> Unit) {
    LazyColumn(verticalArrangement = Arrangement.spacedBy(12.dp)) {
        item {
            Card(colors = CardDefaults.cardColors(containerColor = Panel), shape = RoundedCornerShape(20.dp)) {
                Column(Modifier.padding(20.dp)) {
                    Text("ROOTLESS CYBER WORKSTATION", color = Green, fontSize = 10.sp, letterSpacing = 1.5.sp)
                    Spacer(Modifier.height(10.dp))
                    Text("Your mobile security lab.", color = Color.White, fontSize = 24.sp, fontWeight = FontWeight.Bold)
                    Text("CybX Mobile · ARM64 · Android 16 · No root required", color = Muted, fontSize = 12.sp)
                    Spacer(Modifier.height(18.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Button(onClick = onSetup, modifier = Modifier.weight(1f)) { Text("Linux Setup") }
                        OutlinedButton(onClick = onTerminal, modifier = Modifier.weight(1f), enabled = ready) { Text("Open Terminal") }
                    }
                }
            }
        }
        item {
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                StatusCard(Modifier.weight(1f), "PRoot", if (proot) "Imported" else "Missing", proot)
                StatusCard(Modifier.weight(1f), "Linux rootfs", if (rootfs) "Installed" else "Missing", rootfs)
            }
        }
        item {
            Card(colors = CardDefaults.cardColors(containerColor = Panel)) {
                Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("SYSTEM STATUS", color = Green, fontWeight = FontWeight.Bold)
                    StatusLine("Android app", "READY")
                    StatusLine("Rootless runtime", if (ready) "READY" else "NOT CONFIGURED")
                    StatusLine("Kernel", "Android host kernel")
                    Text(status, color = Muted, fontSize = 11.sp)
                }
            }
        }
        item {
            Card(colors = CardDefaults.cardColors(containerColor = Panel)) {
                Column(Modifier.padding(16.dp)) {
                    Text("CybX Virtual", color = Amber, fontWeight = FontWeight.Bold)
                    Text("Custom-kernel VM is planned for a later phase. This mobile runtime uses Android's kernel.", color = Muted, fontSize = 12.sp)
                }
            }
        }
    }
}

@Composable
private fun StatusCard(modifier: Modifier, label: String, value: String, good: Boolean) {
    Card(modifier, colors = CardDefaults.cardColors(containerColor = Panel)) {
        Column(Modifier.padding(14.dp)) {
            Text(label, color = Muted, fontSize = 11.sp)
            Text(value, color = if (good) Green else Amber, fontWeight = FontWeight.Bold)
        }
    }
}

@Composable
private fun StatusLine(label: String, value: String) {
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
        Text(label, color = Muted, fontSize = 12.sp)
        Text(value, color = Color.White, fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
    }
}

@Composable
private fun InstallPage(proot: Boolean, rootfs: Boolean, sha: String, onSha: (String) -> Unit,
                        busy: Boolean, status: String, onPickProot: () -> Unit, onPickRootfs: () -> Unit) {
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Card(colors = CardDefaults.cardColors(containerColor = Panel)) {
            Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("1 · PRoot runtime", color = Green, fontWeight = FontWeight.Bold)
                Text("Select an audited Android ARM64 PRoot executable. The app checks its ELF architecture, but you must verify its source and SHA-256 before importing.", color = Muted, fontSize = 12.sp)
                Text(if (proot) "PRoot imported" else "PRoot not installed", color = if (proot) Green else Amber)
                OutlinedButton(onClick = onPickProot, enabled = !busy, modifier = Modifier.fillMaxWidth()) {
                    Text("Choose PRoot binary")
                }
            }
        }
        Card(colors = CardDefaults.cardColors(containerColor = Panel)) {
            Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("2 · Kali-derived CybX rootfs", color = Green, fontWeight = FontWeight.Bold)
                Text("Choose the .tar.xz rootfs built with the CybX distro kit. Enter its SHA-256 from a trusted, authenticated release source.", color = Muted, fontSize = 12.sp)
                Text(if (rootfs) "Linux rootfs installed" else "Linux rootfs not installed", color = if (rootfs) Green else Amber)
                OutlinedTextField(value = sha, onValueChange = onSha, modifier = Modifier.fillMaxWidth(),
                    label = { Text("Rootfs SHA-256 (64 hex characters)") }, singleLine = true)
                OutlinedButton(onClick = onPickRootfs, enabled = !busy && sha.matches(Regex("^[A-Fa-f0-9]{64}$")),
                    modifier = Modifier.fillMaxWidth()) { Text("Choose rootfs .tar.xz") }
            }
        }
        if (busy) LinearProgressIndicator(Modifier.fillMaxWidth())
        Text(status, color = Muted, fontSize = 12.sp)
        Text("Security note: checksum verification detects corruption, but a checksum alone does not authenticate who published the file.", color = Amber, fontSize = 11.sp)
    }
}

@Composable
private fun TerminalPage(ready: Boolean, text: String, command: String, onCommand: (String) -> Unit,
                         onRun: () -> Unit, busy: Boolean) {
    Column(Modifier.fillMaxSize(), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        Text(if (ready) "LINUX COMMAND RUNNER · PRoot" else "LINUX RUNTIME NOT READY", color = if (ready) Green else Amber, fontSize = 11.sp, fontWeight = FontWeight.Bold)
        Card(Modifier.weight(1f).fillMaxWidth(), colors = CardDefaults.cardColors(containerColor = Color(0xFF030705))) {
            Text(text, Modifier.fillMaxSize().padding(12.dp).verticalScroll(rememberScrollState()),
                color = Green, fontFamily = FontFamily.Monospace, fontSize = 11.sp)
        }
        OutlinedTextField(value = command, onValueChange = onCommand, modifier = Modifier.fillMaxWidth(),
            enabled = ready && !busy, singleLine = true, label = { Text("Linux command") })
        Button(onClick = onRun, enabled = ready && !busy && command.isNotBlank(), modifier = Modifier.fillMaxWidth()) {
            Text(if (busy) "Running…" else "Execute command")
        }
        Text("Commands run inside the installed rootfs. This first terminal is command-per-process, not a persistent PTY shell.", color = Muted, fontSize = 10.sp)
    }
}

@Composable
private fun ToolsPage(runtimeReady: Boolean) {
    val tools = listOf("Nmap" to "Network discovery for authorized labs", "curl" to "HTTP/API diagnostics",
        "Git" to "Version control", "Python 3" to "Scripting", "OpenSSL" to "TLS and certificate inspection",
        "DNS utilities" to "DNS lookup and diagnostics")
    LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
        item { Text(if (runtimeReady) "TOOLS · INSTALL WITH APT" else "TOOLS CATALOG · RUNTIME REQUIRED", color = Muted, fontSize = 11.sp) }
        items(tools) { (name, description) ->
            Card(colors = CardDefaults.cardColors(containerColor = Panel)) {
                Row(Modifier.fillMaxWidth().padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text(name, color = Green, fontWeight = FontWeight.Bold)
                        Text(description, color = Muted, fontSize = 11.sp)
                    }
                    Text(if (runtimeReady) "AVAILABLE VIA APT" else "LOCKED", color = Muted, fontSize = 9.sp)
                }
            }
        }
        item { Text("Use security tools only on systems you own or are authorized to test.", color = Amber, fontSize = 11.sp) }
    }
}

@Composable
private fun FilesPage(rootfs: java.io.File, ready: Boolean) {
    var current by remember(ready) { mutableStateOf("/") }
    val directory = remember(current, ready) { java.io.File(rootfs, current.trimStart('/')).canonicalFile }
    val entries = remember(directory, ready) { if (ready && directory.isDirectory && directory.path.startsWith(rootfs.canonicalPath)) directory.listFiles()?.sortedBy { it.name } ?: emptyList() else emptyList() }
    Column(Modifier.fillMaxSize(), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        Text(if (ready) "APP-PRIVATE ROOTFS BROWSER" else "ROOTFS NOT INSTALLED", color = Green, fontSize = 11.sp)
        Text(current, color = Muted, fontFamily = FontFamily.Monospace, fontSize = 12.sp)
        if (current != "/") OutlinedButton(onClick = { current = current.substringBeforeLast('/').ifBlank { "/" } }) { Text(".. Parent") }
        if (!ready) Text("Install the Linux rootfs to browse its files.", color = Muted)
        else LazyColumn(verticalArrangement = Arrangement.spacedBy(4.dp)) {
            items(entries) { file ->
                Card(colors = CardDefaults.cardColors(containerColor = Panel)) {
                    Row(Modifier.fillMaxWidth().padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                        Icon(if (file.isDirectory) Icons.Default.Folder else Icons.Default.InsertDriveFile, null, tint = Green)
                        Spacer(Modifier.width(10.dp))
                        Text(file.name, color = Color.White, modifier = Modifier.weight(1f))
                        if (file.isDirectory) TextButton(onClick = { current = (current.trimEnd('/') + "/" + file.name).replace("//", "/") }) { Text("Open") }
                    }
                }
            }
        }
    }
}

@Composable
private fun SettingsPage(status: String) {
    Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Text("CybX OS Mobile · 0.2.0", color = Green, fontWeight = FontWeight.Bold)
        Text("Target ABI: arm64-v8a", color = Muted, fontSize = 12.sp)
        Text("Android host kernel · rootless PRoot userspace", color = Muted, fontSize = 12.sp)
        Text("Runtime status: $status", color = Muted, fontSize = 12.sp)
        Text("CybX Virtual custom-kernel VM will be added after the Android app is stable.", color = Amber, fontSize = 12.sp)
    }
}
