package com.cybx.os.runtime

import java.io.File

/**
 * Adapter boundary for a separately audited Android arm64 PRoot binary.
 * This MVP intentionally refuses to pretend that PRoot is bundled.
 */
class ProotAdapter(private val paths: CybxPaths) {
    private val executable = File(paths.bin, "proot")

    fun isAvailable(): Boolean = executable.isFile && executable.canExecute()

    fun buildShellCommand(command: String): List<String> {
        require(isAvailable()) { "PRoot runtime is not installed. Add the audited arm64 binary first." }
        require(paths.rootfs.isDirectory) { "Kali rootfs is not installed." }
        return listOf(
            executable.absolutePath,
            "-r", paths.rootfs.absolutePath,
            "-b", "/dev",
            "-b", "/proc",
            "-b", "/sys",
            "/usr/bin/env", "-i",
            "HOME=/root", "USER=root", "TERM=xterm-256color",
            "PATH=/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin",
            "/bin/bash", "-lc", command
        )
    }

    fun buildInteractiveShellCommand(): List<String> {
        require(isAvailable()) { "PRoot runtime is not installed. Import an audited ARM64 PRoot binary first." }
        require(paths.rootfs.isDirectory) { "CybX Linux rootfs is not installed." }
        return listOf(
            executable.absolutePath,
            "-r", paths.rootfs.absolutePath,
            "-b", "/dev", "-b", "/proc", "-b", "/sys",
            "/usr/bin/env", "-i",
            "HOME=/root", "USER=root", "LOGNAME=root",
            "LANG=C.UTF-8", "TERM=xterm-256color",
            "PATH=/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin",
            "/bin/bash", "--noprofile", "--norc", "-i"
        )
    }

    fun startInteractiveShell(): Process =
        ProcessBuilder(buildInteractiveShellCommand())
            .directory(paths.rootfs)
            .redirectErrorStream(true)
            .start()
}
