package com.cybx.os.runtime

import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp

@Composable
fun RuntimeSetupScreen(progress: RuntimeProgress, onPrepare: () -> Unit) {
    Column(Modifier.fillMaxWidth().padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Text("Kali Linux ARM64 Runtime", style = MaterialTheme.typography.titleLarge)
        Text(progress.message)
        if (progress.status == RuntimeStatus.DOWNLOADING && progress.totalBytes != null) {
            LinearProgressIndicator(
                progress = { progress.downloadedBytes.toFloat() / progress.totalBytes.toFloat() },
                modifier = Modifier.fillMaxWidth()
            )
        }
        progress.error?.let { Text(it, color = MaterialTheme.colorScheme.error) }
        Button(onClick = onPrepare, enabled = progress.status !in setOf(
            RuntimeStatus.DOWNLOADING, RuntimeStatus.VERIFYING, RuntimeStatus.EXTRACTING,
            RuntimeStatus.INITIALIZING
        )) {
            Text("Prepare Linux environment")
        }
        Text(
            "Root access is not required. Kernel-level wireless monitor mode, raw packet injection " +
                "and privileged network operations are not guaranteed on Android.",
            style = MaterialTheme.typography.bodySmall
        )
    }
}
