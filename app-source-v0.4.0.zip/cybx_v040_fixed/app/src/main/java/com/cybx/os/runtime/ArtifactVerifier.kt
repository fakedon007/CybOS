package com.cybx.os.runtime

import java.io.File
import java.security.MessageDigest

object ArtifactVerifier {
    fun sha256(file: File): String {
        val digest = MessageDigest.getInstance("SHA-256")
        file.inputStream().buffered().use { input ->
            val buffer = ByteArray(1024 * 1024)
            while (true) {
                val read = input.read(buffer)
                if (read <= 0) break
                digest.update(buffer, 0, read)
            }
        }
        return digest.digest().joinToString("") { "%02x".format(it) }
    }

    fun verify(file: File, expectedHex: String): Boolean {
        require(expectedHex.matches(Regex("(?i)[0-9a-f]{64}"))) {
            "A valid pinned SHA-256 checksum is required"
        }
        return sha256(file).equals(expectedHex, ignoreCase = true)
    }
}
