package com.cybx.os.runtime

import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.launch

@Composable
fun CybxRuntimeScreen(
    progress: RuntimeProgress,
    releaseConfigured: Boolean,
    onInstall: suspend (onProgress: (RuntimeProgress) -> Unit) -> Unit
) {
    val scope = rememberCoroutineScope()
    var busy by remember { mutableStateOf(false) }
    Column(
        Modifier.fillMaxWidth().padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Text("CybX Runtime Engine", style = MaterialTheme.typography.headlineSmall)
        Text(progress.message)
        if (progress.status == RuntimeStatus.DOWNLOADING && progress.totalBytes != null && progress.totalBytes > 0) {
            LinearProgressIndicator(
                progress = { progress.downloadedBytes.toFloat() / progress.totalBytes.toFloat() },
                modifier = Modifier.fillMaxWidth()
            )
        } else if (busy) {
            LinearProgressIndicator(modifier = Modifier.fillMaxWidth())
        }
        progress.error?.let { Text(it, color = MaterialTheme.colorScheme.error) }
        if (!releaseConfigured) {
            Text(
                "Rootfs release URL and SHA-256 are not configured. Add a verified release manifest before enabling installation.",
                color = MaterialTheme.colorScheme.error,
                style = MaterialTheme.typography.bodySmall
            )
        }
        Button(
            enabled = releaseConfigured && !busy,
            onClick = {
                busy = true
                scope.launch {
                    try { onInstall { /* caller updates a StateFlow / screen state */ } }
                    finally { busy = false }
                }
            }
        ) { Text(if (busy) "Installing…" else "Install CybX Linux environment") }
        Text(
            "Rootless PRoot userland only. This does not replace Android's kernel. Wireless monitor mode, packet injection and privileged networking are device/kernel dependent.",
            style = MaterialTheme.typography.bodySmall
        )
    }
}
