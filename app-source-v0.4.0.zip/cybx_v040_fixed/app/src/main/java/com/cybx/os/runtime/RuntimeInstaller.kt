package com.cybx.os.runtime

import android.content.Context
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File

/**
 * Orchestrates download -> checksum -> safe extraction -> readiness check.
 * Supply a release URL and SHA-256 from a trusted, signed release manifest.
 */
class RuntimeInstaller(context: Context) {
    private val paths = CybxPaths(context)
    private val downloader = RootfsDownloader(context)
    private val extractor = SafeRootfsExtractor()

    suspend fun install(
        artifact: RootfsArtifact,
        onProgress: (RuntimeProgress) -> Unit
    ) = withContext(Dispatchers.IO) {
        require(artifact.expectedArchitecture == "arm64")
        val archive = paths.rootfsArchive
        onProgress(RuntimeProgress(RuntimeStatus.DOWNLOADING, "Downloading CybX ARM64 rootfs"))
        downloader.download(artifact, archive) { done, total ->
            onProgress(RuntimeProgress(RuntimeStatus.DOWNLOADING, "Downloading rootfs", done, total))
        }
        onProgress(RuntimeProgress(RuntimeStatus.VERIFYING, "Verifying rootfs checksum"))
        check(ArtifactVerifier.verify(archive, artifact.sha256)) {
            "Rootfs SHA-256 mismatch. Archive rejected."
        }
        onProgress(RuntimeProgress(RuntimeStatus.EXTRACTING, "Extracting rootfs safely"))
        val staging = File(paths.base, "rootfs.staging")
        extractor.extractTarXz(archive, staging) { entry ->
            // Keep callback light; UI can show high-level state only.
        }
        check(File(staging, "etc/os-release").isFile && File(staging, "bin/bash").exists()) {
            "Archive does not contain a valid Linux rootfs"
        }
        val final = paths.rootfs
        if (final.exists()) check(final.deleteRecursively()) { "Could not replace old rootfs" }
        check(staging.renameTo(final)) { "Could not activate extracted rootfs" }
        archive.delete()
        onProgress(RuntimeProgress(RuntimeStatus.READY, "CybX OS rootfs installed"))
    }
}
