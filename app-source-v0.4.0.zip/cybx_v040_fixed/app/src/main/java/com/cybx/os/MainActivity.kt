package com.cybx.os

import android.net.Uri
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import com.cybx.os.runtime.CybxPaths
import com.cybx.os.runtime.CybxTerminalHost
import com.cybx.os.runtime.LocalRuntimeInstaller
import com.cybx.os.runtime.ProotAdapter
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import com.termux.view.TerminalView
import java.io.File

private val Bg = Color(0xFF080D0B)
private val Panel = Color(0xFF111A16)
private val Green = Color(0xFF72F59A)
private val Muted = Color(0xFF9AB0A1)
private val Amber = Color(0xFFFFC66D)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { CybXApp() }
    }
}

private enum class Page(val title: String) {
    DASHBOARD("Dashboard"), INSTALL("Linux Setup"), TERMINAL("Terminal"),
    TOOLS("Tools"), FILES("Files"), SETTINGS("Settings")
}

@Composable
fun CybXApp() {
    val context = androidx.compose.ui.platform.LocalContext.current
    val paths = remember { CybxPaths(context) }
    val installer = remember { LocalRuntimeInstaller(context) }
    val terminalHost = remember { CybxTerminalHost(context, paths) }
    val scope = rememberCoroutineScope()

    var page by remember { mutableStateOf(Page.DASHBOARD) }
    var refresh by remember { mutableIntStateOf(0) }
    var statusMessage by remember { mutableStateOf("CybX Mobile ready") }
    var busy by remember { mutableStateOf(false) }

    DisposableEffect(terminalHost) {
        onDispose { terminalHost.close() }
    }

    val rootfsAvailable = remember(refresh) { paths.isRootfsInstalled() }
    val prootAvailable = remember(refresh) {
        ProotAdapter(context, paths).isAvailable()
    }
    val runtimeProblem = remember(refresh) { ProotAdapter(context, paths).readinessError() }
    val runtimeReady = runtimeProblem == null

    val rootfsPicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri: Uri? ->
        if (uri != null) scope.launch {
            busy = true
            statusMessage = "Preparing selected Kali rootfs…"
            try {
                withContext(Dispatchers.IO) {
                    installer.importRootfs(uri) { message ->
                        scope.launch(Dispatchers.Main) { statusMessage = message }
                    }
                }
                statusMessage = "Kali rootfs verified and installed"
                refresh++
            } catch (e: Exception) {
                statusMessage = e.message ?: "Rootfs import failed"
            } finally {
                busy = false
            }
        }
    }

    MaterialTheme(colorScheme = darkColorScheme(
        primary = Green, background = Bg, surface = Panel,
        onBackground = Color.White, onSurface = Color.White,
        secondary = Amber
    )) {
        Scaffold(
            containerColor = Bg,
            topBar = {
                Row(
                    Modifier.fillMaxWidth().background(Color(0xFF0B120F)).padding(horizontal = 16.dp, vertical = 9.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Image(painterResource(R.mipmap.ic_launcher), contentDescription = "CybX OS logo", modifier = Modifier.size(38.dp))
                    Spacer(Modifier.width(10.dp))
                    Column {
                        Text("CYBX OS", color = Green, fontSize = 11.sp, fontWeight = FontWeight.Black, letterSpacing = 3.sp)
                        Text(page.title, color = Color.White, fontSize = 22.sp, fontWeight = FontWeight.Bold)
                    }
                }
            },
            bottomBar = {
                NavigationBar(containerColor = Color(0xFF0B120F), tonalElevation = 0.dp) {
                    val entries = listOf(Page.DASHBOARD, Page.INSTALL, Page.TERMINAL, Page.TOOLS, Page.FILES, Page.SETTINGS)
                    entries.forEach { item ->
                        NavigationBarItem(
                            selected = page == item,
                            onClick = { page = item },
                            icon = {
                                Icon(when (item) {
                                    Page.DASHBOARD -> Icons.Default.Dashboard
                                    Page.INSTALL -> Icons.Default.Download
                                    Page.TERMINAL -> Icons.Default.Terminal
                                    Page.TOOLS -> Icons.Default.Build
                                    Page.FILES -> Icons.Default.Folder
                                    else -> Icons.Default.Settings
                                }, contentDescription = item.title)
                            },
                            label = { Text(item.title, fontSize = 9.sp) },
                            colors = NavigationBarItemDefaults.colors(selectedIconColor = Green, selectedTextColor = Green)
                        )
                    }
                }
            }
        ) { padding ->
            Column(Modifier.fillMaxSize().padding(padding).padding(horizontal = 16.dp, vertical = 12.dp)) {
                when (page) {
                    Page.DASHBOARD -> DashboardPage(
                        runtimeReady, prootAvailable, rootfsAvailable, statusMessage,
                        onSetup = { page = Page.INSTALL },
                        onTerminal = { page = Page.TERMINAL }
                    )
                    Page.INSTALL -> InstallPage(
                        prootAvailable = prootAvailable,
                        rootfs = rootfsAvailable,
                        busy = busy,
                        status = statusMessage,
                        problem = runtimeProblem,
                        onPickRootfs = {
                            rootfsPicker.launch(arrayOf("application/x-xz", "application/octet-stream", "application/octet-stream+gzip", "*/*"))
                        }
                    )
                    Page.TERMINAL -> TerminalPage(
                        ready = runtimeReady,
                        problem = runtimeProblem,
                        host = terminalHost,
                    )
                    Page.TOOLS -> ToolsPage(runtimeReady)
                    Page.FILES -> FilesPage(paths.rootfs, runtimeReady)
                    Page.SETTINGS -> SettingsPage(statusMessage)
                }
            }
        }
    }
}

@Composable
private fun DashboardPage(
    ready: Boolean,
    proot: Boolean,
    rootfs: Boolean,
    status: String,
    onSetup: () -> Unit,
    onTerminal: () -> Unit
) {
    LazyColumn(verticalArrangement = Arrangement.spacedBy(12.dp)) {
        item {
            Card(colors = CardDefaults.cardColors(containerColor = Panel), shape = RoundedCornerShape(20.dp)) {
                Column(Modifier.padding(20.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Image(painterResource(R.mipmap.ic_launcher), null, modifier = Modifier.size(58.dp))
                        Spacer(Modifier.width(12.dp))
                        Column {
                            Text("ROOTLESS CYBER WORKSTATION", color = Green, fontSize = 10.sp, letterSpacing = 1.2.sp)
                            Text("CybX Mobile", color = Color.White, fontSize = 23.sp, fontWeight = FontWeight.Bold)
                        }
                    }
                    Spacer(Modifier.height(8.dp))
                    Text("Your mobile Linux security lab.", color = Color.White, fontSize = 17.sp, fontWeight = FontWeight.SemiBold)
                    Text("ARM64 · Android host kernel · No root required", color = Muted, fontSize = 12.sp)
                    Spacer(Modifier.height(18.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Button(onClick = onSetup, modifier = Modifier.weight(1f)) { Text("Linux Setup") }
                        OutlinedButton(onClick = onTerminal, modifier = Modifier.weight(1f), enabled = ready) { Text("Open Terminal") }
                    }
                }
            }
        }
        item {
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                StatusCard(Modifier.weight(1f), "PRoot", if (proot) "Bundled" else "Missing", proot)
                StatusCard(Modifier.weight(1f), "Kali rootfs", if (rootfs) "Installed" else "Missing", rootfs)
            }
        }
        item {
            Card(colors = CardDefaults.cardColors(containerColor = Panel)) {
                Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("SYSTEM STATUS", color = Green, fontWeight = FontWeight.Bold)
                    StatusLine("Android app", "READY")
                    StatusLine("Rootless runtime", if (ready) "READY" else "NOT CONFIGURED")
                    StatusLine("Terminal", "PTY + ANSI emulator")
                    StatusLine("Kernel", "Android host kernel")
                    Text(status, color = Muted, fontSize = 11.sp)
                }
            }
        }
        item {
            Card(colors = CardDefaults.cardColors(containerColor = Panel)) {
                Column(Modifier.padding(16.dp)) {
                    Text("CybX Virtual", color = Amber, fontWeight = FontWeight.Bold)
                    Text("Custom-kernel VM is planned for a later phase. This mobile runtime uses Android's kernel.", color = Muted, fontSize = 12.sp)
                }
            }
        }
    }
}

@Composable
private fun StatusCard(modifier: Modifier, label: String, value: String, good: Boolean) {
    Card(modifier, colors = CardDefaults.cardColors(containerColor = Panel)) {
        Column(Modifier.padding(14.dp)) {
            Text(label, color = Muted, fontSize = 11.sp)
            Text(value, color = if (good) Green else Amber, fontWeight = FontWeight.Bold)
        }
    }
}

@Composable
private fun StatusLine(label: String, value: String) {
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
        Text(label, color = Muted, fontSize = 12.sp)
        Text(value, color = Color.White, fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
    }
}

@Composable
private fun InstallPage(
    prootAvailable: Boolean,
    rootfs: Boolean,
    busy: Boolean,
    status: String,
    problem: String?,
    onPickRootfs: () -> Unit
) {
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Card(colors = CardDefaults.cardColors(containerColor = Panel)) {
            Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("1 · Android ARM64 PRoot", color = Green, fontWeight = FontWeight.Bold)
                Text("PRoot is bundled inside the APK and executed from Android's protected native-library directory.", color = Muted, fontSize = 12.sp)
                Text(if (prootAvailable) "Bundled PRoot available" else "PRoot library missing — reinstall CybX Mobile", color = if (prootAvailable) Green else Amber)
            }
        }
        Card(colors = CardDefaults.cardColors(containerColor = Panel)) {
            Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("2 · Kali NetHunter Minimal ARM64", color = Green, fontWeight = FontWeight.Bold)
                Text(
                    "Choose kali-nethunter-rootfs-minimal-arm64.tar.xz from the CybX Runtime Bundle. CybX calculates SHA-256 automatically and checks it against the pinned official Kali checksum. No manual hash is needed.",
                    color = Muted, fontSize = 12.sp
                )
                Text(if (rootfs) "Kali rootfs installed and validated" else "Kali rootfs not installed", color = if (rootfs) Green else Amber)
                OutlinedButton(onClick = onPickRootfs, enabled = !busy && prootAvailable, modifier = Modifier.fillMaxWidth()) {
                    Icon(Icons.Default.FolderOpen, null)
                    Spacer(Modifier.width(8.dp))
                    Text("Choose Kali rootfs .tar.xz")
                }
                if (problem != null && prootAvailable) Text(problem, color = Amber, fontSize = 11.sp)
            }
        }
        if (busy) LinearProgressIndicator(Modifier.fillMaxWidth())
        Text(status, color = Muted, fontSize = 12.sp)
        Text(
            "Only the pinned Kali NetHunter Minimal ARM64 archive is accepted. The checksum verifies the file bytes against the pinned release; it does not authenticate any unrelated file or publisher outside that release.",
            color = Amber, fontSize = 11.sp
        )
    }
}

@Composable
private fun TerminalPage(ready: Boolean, problem: String?, host: CybxTerminalHost) {
    Column(Modifier.fillMaxSize(), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text(if (ready) "KALI LINUX · INTERACTIVE PTY" else "LINUX RUNTIME NOT READY", color = if (ready) Green else Amber, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                Text("Bash · ANSI colours · terminal resize · persistent session", color = Muted, fontSize = 10.sp)
            }
            TextButton(onClick = { host.restart() }, enabled = ready) { Text("Restart") }
        }
        if (!ready) {
            Card(Modifier.weight(1f).fillMaxWidth(), colors = CardDefaults.cardColors(containerColor = Panel)) {
                Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("Kali environment is not ready", color = Amber, fontWeight = FontWeight.Bold)
                    Text(problem ?: "Open Linux Setup and install the verified Kali ARM64 rootfs.", color = Muted)
                }
            }
        } else {
            AndroidView(
                modifier = Modifier.weight(1f).fillMaxWidth(),
                factory = { ctx -> TerminalView(ctx, null).apply { host.attach(this) } },
                update = { view -> host.attach(view) }
            )
            Row(
                Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()),
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                TerminalKey("ESC") { host.send("\u001B") }
                TerminalKey("TAB") { host.send("\t") }
                TerminalKey("CTRL+C") { host.send("\u0003") }
                TerminalKey("CTRL+D") { host.send("\u0004") }
                TerminalKey("↑") { host.send("\u001B[A") }
                TerminalKey("↓") { host.send("\u001B[B") }
                TerminalKey("←") { host.send("\u001B[D") }
                TerminalKey("→") { host.send("\u001B[C") }
            }
        }
    }
}

@Composable
private fun TerminalKey(label: String, onClick: () -> Unit) {
    OutlinedButton(onClick = onClick, contentPadding = PaddingValues(horizontal = 12.dp, vertical = 4.dp)) {
        Text(label, fontFamily = FontFamily.Monospace, fontSize = 11.sp)
    }
}

@Composable
private fun ToolsPage(runtimeReady: Boolean) {
    val tools = listOf(
        "Nmap" to "Network discovery for authorized labs",
        "curl" to "HTTP/API diagnostics",
        "Git" to "Version control",
        "Python 3" to "Scripting",
        "OpenSSL" to "TLS and certificate inspection",
        "DNS utilities" to "DNS lookup and diagnostics"
    )
    LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
        item { Text(if (runtimeReady) "TOOLS · INSTALL WITH APT" else "TOOLS CATALOG · RUNTIME REQUIRED", color = Muted, fontSize = 11.sp) }
        items(tools) { (name, description) ->
            Card(colors = CardDefaults.cardColors(containerColor = Panel)) {
                Row(Modifier.fillMaxWidth().padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text(name, color = Green, fontWeight = FontWeight.Bold)
                        Text(description, color = Muted, fontSize = 11.sp)
                    }
                    Text(if (runtimeReady) "AVAILABLE VIA APT" else "LOCKED", color = Muted, fontSize = 9.sp)
                }
            }
        }
        item { Text("Use security tools only on systems you own or are authorized to test.", color = Amber, fontSize = 11.sp) }
    }
}

@Composable
private fun FilesPage(rootfs: File, ready: Boolean) {
    var current by remember(ready) { mutableStateOf("/") }
    val directory = remember(current, ready) { File(rootfs, current.trimStart('/')).canonicalFile }
    val root = remember(rootfs) { rootfs.canonicalFile }
    val safeDirectory = directory.path == root.path || directory.path.startsWith(root.path + File.separator)
    val entries = remember(directory, ready, safeDirectory) {
        if (ready && safeDirectory && directory.isDirectory) directory.listFiles()?.sortedBy { it.name } ?: emptyList() else emptyList()
    }
    Column(Modifier.fillMaxSize(), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        Text(if (ready) "KALI ROOTFS FILE BROWSER" else "ROOTFS NOT INSTALLED", color = Green, fontSize = 11.sp)
        Text(current, color = Muted, fontFamily = FontFamily.Monospace, fontSize = 12.sp)
        if (current != "/") OutlinedButton(onClick = { current = current.substringBeforeLast('/').ifBlank { "/" } }) { Text(".. Parent") }
        if (!ready) Text("Install the Linux rootfs to browse its files.", color = Muted)
        else LazyColumn(verticalArrangement = Arrangement.spacedBy(4.dp)) {
            items(entries) { file ->
                Card(colors = CardDefaults.cardColors(containerColor = Panel)) {
                    Row(Modifier.fillMaxWidth().padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                        Icon(if (file.isDirectory) Icons.Default.Folder else Icons.Default.InsertDriveFile, null, tint = Green)
                        Spacer(Modifier.width(10.dp))
                        Text(file.name, color = Color.White, modifier = Modifier.weight(1f))
                        if (file.isDirectory) TextButton(onClick = {
                            current = (current.trimEnd('/') + "/" + file.name).replace("//", "/")
                        }) { Text("Open") }
                    }
                }
            }
        }
    }
}

@Composable
private fun SettingsPage(status: String) {
    Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Text("CybX OS Mobile · 0.4.0", color = Green, fontWeight = FontWeight.Bold)
        Text("Target ABI: arm64-v8a", color = Muted, fontSize = 12.sp)
        Text("Android host kernel · rootless PRoot userspace", color = Muted, fontSize = 12.sp)
        Text("Terminal: Termux TerminalView / PTY (Apache-2.0 libraries)", color = Muted, fontSize = 12.sp)
        Text("Runtime status: $status", color = Muted, fontSize = 12.sp)
        Text("CybX Virtual custom-kernel VM will be added after the Android app is stable.", color = Amber, fontSize = 12.sp)
    }
}
