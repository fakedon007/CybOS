package com.cybx.os.runtime

import android.content.Context
import android.net.Uri
import android.system.Os
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File
import java.security.MessageDigest

/**
 * Imports the pinned official Kali NetHunter Minimal ARM64 rootfs.
 * The expected digest is built into the application: users only select the archive.
 */
class LocalRuntimeInstaller(context: Context) {
    private val appContext = context.applicationContext
    private val paths = CybxPaths(appContext)
    private val extractor = SafeRootfsExtractor()

    companion object {
        // SHA-256 from the official Kali NetHunter current/rootfs SHA256SUMS file
        // for kali-nethunter-rootfs-minimal-arm64.tar.xz (pinned release bundle v1.0).
        const val KALI_MINIMAL_ARM64_SHA256 =
            "96aeced81a857a987715a14417af05c2934e3e19052d6151c398a1c215448b60"
        private const val MAX_ROOTFS_ARCHIVE_BYTES = 2_500_000_000L
    }

    suspend fun importRootfs(uri: Uri, onProgress: (String) -> Unit) =
        withContext(Dispatchers.IO) {
            check(paths.prootExecutable.isFile && paths.prootExecutable.canExecute()) {
                "Bundled PRoot is missing. Reinstall CybX Mobile."
            }
            paths.downloads.mkdirs()
            val temp = File(paths.downloads, "rootfs-import.part")
            if (temp.exists()) temp.delete()

            onProgress("Copying selected Kali rootfs…")
            appContext.contentResolver.openInputStream(uri)?.use { input ->
                temp.outputStream().buffered().use { output ->
                    val buffer = ByteArray(256 * 1024)
                    var total = 0L
                    while (true) {
                        val count = input.read(buffer)
                        if (count < 0) break
                        total += count
                        require(total <= MAX_ROOTFS_ARCHIVE_BYTES) { "Selected file is too large to be a supported Kali rootfs archive" }
                        output.write(buffer, 0, count)
                    }
                }
            } ?: error("Cannot read selected rootfs archive")
            require(temp.isFile && temp.length() > 0) { "Selected rootfs archive is empty" }

            onProgress("Calculating and verifying SHA-256…")
            val actual = sha256(temp)
            require(actual.equals(KALI_MINIMAL_ARM64_SHA256, ignoreCase = true)) {
                "This is not the pinned official Kali NetHunter Minimal ARM64 archive. SHA-256 verification failed. Select the original .tar.xz from the CybX Runtime Bundle v1.0."
            }

            onProgress("Extracting Kali ARM64 filesystem safely…")
            val staging = File(paths.base, "rootfs.import-staging")
            val ready = File(paths.base, "rootfs.import-ready")
            val backup = File(paths.base, "rootfs.previous")
            staging.deleteRecursively()
            ready.deleteRecursively()
            extractor.extractTarXz(temp, staging)

            val candidates = buildList {
                if (isRootfsCandidate(staging)) add(staging)
                staging.listFiles()?.filter { it.isDirectory && isRootfsCandidate(it) }?.forEach { add(it) }
            }
            require(candidates.size == 1) {
                "Archive layout is not supported: expected exactly one Kali rootfs containing etc/os-release, usr/bin/env and bash"
            }
            val candidate = candidates.single()
            val release = File(candidate, "etc/os-release").readText()
            require(release.contains("ID=kali") || release.contains("ID=\"kali\"")) {
                "Selected archive is not identified as Kali Linux"
            }

            listOf("dev", "proc", "sys", "tmp", "root", "run", "dev/shm").forEach {
                File(candidate, it).mkdirs()
            }
            runCatching { Os.chmod(File(candidate, "tmp").absolutePath, 0x3FF) } // 01777
            if (candidate == staging) {
                check(staging.renameTo(ready)) { "Could not stage the validated Kali rootfs" }
            } else {
                check(candidate.renameTo(ready)) { "Could not stage the validated Kali rootfs" }
                staging.deleteRecursively()
            }

            // Replace atomically on the same app-private filesystem and restore the previous
            // install if activation fails. A partially extracted tree is never marked ready.
            backup.deleteRecursively()
            if (paths.rootfs.exists()) {
                check(paths.rootfs.renameTo(backup)) { "Could not preserve the current rootfs before update" }
            }
            if (!ready.renameTo(paths.rootfs)) {
                if (backup.exists()) backup.renameTo(paths.rootfs)
                error("Could not activate the new Kali rootfs")
            }
            backup.deleteRecursively()
            temp.delete()
            onProgress("Kali Linux verified and installed")
        }

    private fun isRootfsCandidate(dir: File): Boolean {
        if (!File(dir, "etc/os-release").isFile) return false
        val hasEnv = File(dir, "usr/bin/env").isFile || File(dir, "bin/env").isFile
        val hasBash = File(dir, "bin/bash").isFile || File(dir, "usr/bin/bash").isFile
        return hasEnv && hasBash
    }

    private fun sha256(file: File): String {
        val digest = MessageDigest.getInstance("SHA-256")
        file.inputStream().buffered().use { input ->
            val buffer = ByteArray(1024 * 1024)
            while (true) {
                val read = input.read(buffer)
                if (read < 0) break
                digest.update(buffer, 0, read)
            }
        }
        return digest.digest().joinToString("") { "%02x".format(it) }
    }

}
