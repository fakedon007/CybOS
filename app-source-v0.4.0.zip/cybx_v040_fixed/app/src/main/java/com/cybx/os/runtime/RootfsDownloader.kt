package com.cybx.os.runtime

import android.content.Context
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File
import java.net.HttpURLConnection
import java.net.URL

class RootfsDownloader(private val context: Context) {
    suspend fun download(artifact: RootfsArtifact, destination: File,
                         onProgress: (Long, Long?) -> Unit) = withContext(Dispatchers.IO) {
        require(artifact.url.startsWith("https://")) { "Only HTTPS rootfs downloads are allowed" }
        require(artifact.expectedArchitecture == "arm64") { "Only ARM64 rootfs is supported" }
        val connectivity = context.getSystemService(ConnectivityManager::class.java)
        val network = connectivity.activeNetwork
        val caps = connectivity.getNetworkCapabilities(network)
        require(caps?.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET) == true) {
            "No internet connection"
        }

        destination.parentFile?.mkdirs()
        val connection = (URL(artifact.url).openConnection() as HttpURLConnection).apply {
            connectTimeout = 20_000
            readTimeout = 60_000
            instanceFollowRedirects = true
            setRequestProperty("User-Agent", "CybX-OS/0.1")
        }
        try {
            connection.connect()
            require(connection.responseCode in 200..299) {
                "Download failed: HTTP ${connection.responseCode}"
            }
            val total = connection.contentLengthLong.takeIf { it > 0 }
            val temp = File(destination.parentFile, destination.name + ".part")
            connection.inputStream.buffered().use { input ->
                temp.outputStream().buffered().use { output ->
                    val buffer = ByteArray(128 * 1024)
                    var count = 0L
                    while (true) {
                        val n = input.read(buffer)
                        if (n < 0) break
                        output.write(buffer, 0, n)
                        count += n
                        onProgress(count, total)
                    }
                }
            }
            require(temp.length() > 0) { "Downloaded archive is empty" }
            if (destination.exists()) destination.delete()
            check(temp.renameTo(destination)) { "Unable to finalize downloaded archive" }
        } finally {
            connection.disconnect()
        }
    }
}
