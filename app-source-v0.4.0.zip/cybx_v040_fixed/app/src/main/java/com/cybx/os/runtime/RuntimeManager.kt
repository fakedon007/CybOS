package com.cybx.os.runtime

import android.content.Context
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import java.io.File

class RuntimeManager(context: Context) {
    val paths = CybxPaths(context)
    private val _progress = MutableStateFlow(RuntimeProgress())
    val progress: StateFlow<RuntimeProgress> = _progress.asStateFlow()
    val proot = ProotAdapter(context, paths)

    fun markError(message: String) {
        _progress.value = RuntimeProgress(
            status = RuntimeStatus.ERROR,
            message = "Runtime setup failed",
            error = message
        )
    }

    fun markReady() {
        _progress.value = RuntimeProgress(
            status = RuntimeStatus.READY,
            message = "Kali userspace is ready"
        )
    }

    fun rootfsInstalled(): Boolean =
        File(paths.rootfs, "bin/bash").exists() && File(paths.rootfs, "etc/os-release").exists()
}
