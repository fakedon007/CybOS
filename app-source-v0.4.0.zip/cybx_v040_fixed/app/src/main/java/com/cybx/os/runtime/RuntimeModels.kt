package com.cybx.os.runtime

enum class RuntimeStatus {
    NOT_INSTALLED, DOWNLOADING, VERIFYING, EXTRACTING, INITIALIZING, READY, ERROR
}

data class RuntimeProgress(
    val status: RuntimeStatus = RuntimeStatus.NOT_INSTALLED,
    val message: String = "Kali ARM64 environment is not installed",
    val downloadedBytes: Long = 0,
    val totalBytes: Long? = null,
    val error: String? = null
)

data class RootfsArtifact(
    val url: String,
    val sha256: String,
    val fileName: String,
    val expectedArchitecture: String = "arm64"
)
