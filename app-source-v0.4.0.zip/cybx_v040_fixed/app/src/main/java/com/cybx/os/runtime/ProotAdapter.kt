package com.cybx.os.runtime

import android.content.Context
import com.termux.terminal.TerminalSession
import com.termux.terminal.TerminalSessionClient

/** Creates a real PTY-backed Kali login shell using the bundled Android ARM64 PRoot. */
class ProotAdapter(private val context: Context, private val paths: CybxPaths) {
    fun isAvailable(): Boolean = paths.prootExecutable.isFile &&
        paths.prootExecutable.canExecute() && paths.prootExecutable.length() > 0

    fun readinessError(): String? {
        if (!isAvailable()) return "Bundled ARM64 PRoot is missing. Reinstall CybX Mobile."
        return paths.rootfsProblem()
    }

    fun createTerminalSession(client: TerminalSessionClient): TerminalSession {
        readinessError()?.let { error(it) }
        paths.prootTmp.mkdirs()
        paths.rootHome.mkdirs()
        paths.sharedMemory.mkdirs()
        check(paths.prootTmp.isDirectory && paths.prootTmp.canWrite()) {
            "CybX cannot write to its PRoot temporary directory"
        }

        val executable = paths.prootExecutable.absolutePath
        val rootfs = paths.rootfs.absolutePath
        val argv = arrayOf(
            executable,
            "--link2symlink", "-0",
            "-r", rootfs,
            "-b", "/dev", "-b", "/proc", "-b", "/sys",
            "-b", "${paths.sharedMemory.absolutePath}:/dev/shm",
            "-w", "/root",
            "/usr/bin/env", "-i",
            "HOME=/root", "USER=root", "LOGNAME=root", "SHELL=/bin/bash",
            "LANG=C.UTF-8", "TERM=xterm-256color", "COLORTERM=truecolor",
            "PATH=/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin",
            "/bin/bash", "--login", "-i"
        )
        val env = arrayOf(
            "PATH=/system/bin:/system/xbin",
            "HOME=${paths.rootHome.absolutePath}",
            "TMPDIR=${paths.prootTmp.absolutePath}",
            "PROOT_TMP_DIR=${paths.prootTmp.absolutePath}",
            "TERM=xterm-256color",
            "LANG=C.UTF-8"
        )
        // Termux TerminalSession supplies a real PTY (forkpty), terminal resize, VT parsing,
        // ANSI colours, interactive input and job-control signals to the child process.
        return TerminalSession(
            executable,
            paths.base.absolutePath,
            argv,
            env,
            3000,
            client
        )
    }
}
