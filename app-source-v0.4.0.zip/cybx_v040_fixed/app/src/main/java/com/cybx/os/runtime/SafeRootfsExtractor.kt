package com.cybx.os.runtime

import android.system.Os
import org.apache.commons.compress.compressors.xz.XZCompressorInputStream
import org.apache.commons.compress.archivers.tar.TarArchiveInputStream
import java.io.BufferedInputStream
import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream
import java.io.IOException
import java.nio.file.Files
import java.nio.file.Path
import java.nio.file.LinkOption

/**
 * Extracts a tar.xz rootfs into an app-private directory.
 * Rejects path traversal, absolute paths, escaping symlinks and hardlinks.
 * Special device/socket entries are ignored; Android cannot provide a normal Linux /dev.
 */
class SafeRootfsExtractor {
    fun extractTarXz(archive: File, destination: File, onEntry: (String) -> Unit = {}) {
        require(archive.isFile && archive.length() > 0) { "Rootfs archive is missing or empty" }
        val root = destination.canonicalFile
        if (root.exists()) root.deleteRecursively()
        check(root.mkdirs()) { "Could not create rootfs directory" }
        val rootPath = root.toPath()

        FileInputStream(archive).use { fis ->
            BufferedInputStream(fis).use { buffered ->
                XZCompressorInputStream(buffered).use { xz ->
                    TarArchiveInputStream(xz).use { tar ->
                        while (true) {
                            val entry = tar.nextTarEntry ?: break
                            val name = entry.name
                            val target = safeTarget(rootPath, name)
                            val parentCanonical = target.parent.toFile().canonicalFile.toPath()
                            if (!parentCanonical.startsWith(rootPath)) {
                                throw IOException("Archive entry traverses an existing symlink: $name")
                            }
                            onEntry(name)
                            when {
                                entry.isDirectory -> {
                                    Files.createDirectories(target)
                                    applyMode(target.toFile(), entry.mode)
                                }
                                entry.isSymbolicLink -> {
                                    val link = entry.linkName
                                    val resolved = resolveLinkTarget(rootPath, target.parent, link)
                                    if (!resolved.startsWith(rootPath)) {
                                        throw IOException("Symlink escapes rootfs: $name -> $link")
                                    }
                                    Files.createDirectories(target.parent)
                                    Files.deleteIfExists(target)
                                    // Keep the original link text: absolute links are interpreted
                                    // inside the PRoot root, not on the Android host filesystem.
                                    Os.symlink(link, target.toString())
                                }
                                entry.isFile -> {
                                    Files.createDirectories(target.parent)
                                    Files.newOutputStream(target).use { out ->
                                        var remaining = entry.size
                                        val buffer = ByteArray(64 * 1024)
                                        while (remaining > 0) {
                                            val count = tar.read(buffer, 0, minOf(buffer.size.toLong(), remaining).toInt())
                                            if (count < 0) throw IOException("Truncated archive entry: $name")
                                            out.write(buffer, 0, count)
                                            remaining -= count
                                        }
                                    }
                                    applyMode(target.toFile(), entry.mode)
                                }
                                entry.isLink -> {
                                    // Debian/Kali rootfs archives legitimately contain hard links.
                                    // Accept only archive-internal links to an already extracted
                                    // regular file; never allow links to host paths or future paths.
                                    val linkTarget = safeTarget(rootPath, entry.linkName)
                                    val canonicalLink = linkTarget.toFile().canonicalFile.toPath()
                                    if (!canonicalLink.startsWith(rootPath) ||
                                        !Files.isRegularFile(linkTarget, LinkOption.NOFOLLOW_LINKS)) {
                                        throw IOException("Unsafe or unresolved hard link: $name -> ${entry.linkName}")
                                    }
                                    Files.createDirectories(target.parent)
                                    Files.deleteIfExists(target)
                                    Files.createLink(target, linkTarget)
                                }
                                else -> {
                                    // Skip device nodes, FIFOs and other special entries.
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    private fun resolveLinkTarget(root: Path, parent: Path, link: String): Path {
        if (link.isEmpty() || link.contains('\u0000')) throw IOException("Invalid symlink target")
        // Inside a chroot/PRoot root, an absolute link such as /usr/bin/bash
        // resolves from the rootfs directory, not from Android's /.
        val resolved = if (link.startsWith("/")) {
            root.resolve(link.trimStart('/')).normalize()
        } else {
            parent.resolve(link).normalize()
        }
        if (!resolved.startsWith(root)) throw IOException("Symlink target escapes rootfs: $link")
        return resolved
    }

    private fun safeTarget(root: Path, rawName: String): Path {
        if (rawName.startsWith("/") || rawName.contains('\u0000')) {
            throw IOException("Absolute or invalid archive path: $rawName")
        }
        val normalized = root.resolve(rawName).normalize()
        if (!normalized.startsWith(root)) throw IOException("Archive path traversal: $rawName")
        return normalized
    }

    private fun applyMode(file: File, mode: Int) {
        // Preserve the archive's ordinary permission bits (setuid/setgid/sticky are stripped).
        Os.chmod(file.absolutePath, mode and 0x1FF)
    }
}
