package com.cybx.os.runtime

import android.content.Context
import java.io.File

class CybxPaths(context: Context) {
    private val appContext = context.applicationContext
    val base = File(appContext.filesDir, "cybx").apply { mkdirs() }

    // PRoot is packaged as an APK native library so Android extracts it into its
    // read-only nativeLibraryDir. Do not copy it to filesDir: Android W^X blocks exec there.
    val prootExecutable = File(appContext.applicationInfo.nativeLibraryDir, "libproot.so")

    val rootfs = File(base, "rootfs")
    val downloads = File(base, "downloads").apply { mkdirs() }
    val prootTmp = File(base, "proot-tmp").apply { mkdirs() }
    val rootHome = File(base, "home-root").apply { mkdirs() }
    val sharedMemory = File(base, "shm").apply { mkdirs() }
    val rootfsArchive = File(downloads, "cybx-kali-arm64-rootfs-minimal.tar.xz")

    fun rootfsProblem(): String? {
        if (!rootfs.isDirectory) return "Kali rootfs directory is missing"
        if (!File(rootfs, "etc/os-release").isFile) return "Rootfs is incomplete: /etc/os-release is missing"
        val env = File(rootfs, "usr/bin/env").isFile || File(rootfs, "bin/env").isFile
        if (!env) return "Rootfs is incomplete: /usr/bin/env is missing"
        val bash = File(rootfs, "bin/bash").isFile || File(rootfs, "usr/bin/bash").isFile
        if (!bash) return "Rootfs is incomplete: /bin/bash is missing"
        return null
    }

    fun isRootfsInstalled(): Boolean = rootfsProblem() == null

    fun isRuntimeReady(): Boolean = prootExecutable.isFile && prootExecutable.canExecute() && rootfsProblem() == null
}
