package com.cybx.os.runtime

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.graphics.Color
import android.graphics.Typeface
import android.view.KeyEvent
import android.view.MotionEvent
import android.view.inputmethod.InputMethodManager
import android.widget.Toast
import com.termux.terminal.TerminalSession
import com.termux.terminal.TerminalSessionClient
import com.termux.view.TerminalView
import com.termux.view.TerminalViewClient

/** Keeps one interactive PTY shell alive while the user moves between CybX tabs. */
class CybxTerminalHost(
    private val context: Context,
    private val paths: CybxPaths
) {
    private var terminalView: TerminalView? = null
    private var session: TerminalSession? = null

    private val sessionClient = object : TerminalSessionClient {
        override fun onTextChanged(changedSession: TerminalSession) {
            terminalView?.postInvalidate()
        }

        override fun onTitleChanged(changedSession: TerminalSession) {
            terminalView?.postInvalidate()
        }

        override fun onSessionFinished(finishedSession: TerminalSession) {
            terminalView?.postInvalidate()
        }

        override fun onCopyTextToClipboard(session: TerminalSession, text: String) {
            val clipboard = context.getSystemService(ClipboardManager::class.java)
            clipboard.setPrimaryClip(ClipData.newPlainText("CybX Terminal", text))
            Toast.makeText(context, "Copied", Toast.LENGTH_SHORT).show()
        }

        override fun onPasteTextFromClipboard(session: TerminalSession) {
            val clipboard = context.getSystemService(ClipboardManager::class.java)
            val text = clipboard.primaryClip?.getItemAt(0)?.coerceToText(context)?.toString() ?: return
            val bytes = text.toByteArray(Charsets.UTF_8)
            session.write(bytes, 0, bytes.size)
        }

        override fun onBell(session: TerminalSession) = Unit
        override fun onColorsChanged(session: TerminalSession) { terminalView?.postInvalidate() }
        override fun onTerminalCursorStateChange(state: Boolean) { terminalView?.postInvalidate() }
        override fun getTerminalCursorStyle(): Int? = null
        override fun logError(tag: String, message: String) = Unit
        override fun logWarn(tag: String, message: String) = Unit
        override fun logInfo(tag: String, message: String) = Unit
        override fun logDebug(tag: String, message: String) = Unit
        override fun logVerbose(tag: String, message: String) = Unit
        override fun logStackTraceWithMessage(tag: String, message: String, e: Exception) = Unit
        override fun logStackTrace(tag: String, e: Exception) = Unit
    }

    private val viewClient = object : TerminalViewClient {
        override fun onScale(scale: Float): Float = scale

        override fun onSingleTapUp(e: MotionEvent) {
            terminalView?.let { view ->
                view.requestFocus()
                context.getSystemService(InputMethodManager::class.java)
                    .showSoftInput(view, InputMethodManager.SHOW_IMPLICIT)
            }
        }

        override fun shouldBackButtonBeMappedToEscape(): Boolean = true
        override fun shouldEnforceCharBasedInput(): Boolean = true
        override fun shouldUseCtrlSpaceWorkaround(): Boolean = false
        override fun isTerminalViewSelected(): Boolean = true
        override fun copyModeChanged(copyMode: Boolean) = Unit
        override fun onKeyDown(keyCode: Int, e: KeyEvent, session: TerminalSession): Boolean = false
        override fun onKeyUp(keyCode: Int, e: KeyEvent): Boolean = false
        override fun onLongPress(event: MotionEvent): Boolean = false
        override fun readControlKey(): Boolean = false
        override fun readAltKey(): Boolean = false
        override fun readShiftKey(): Boolean = false
        override fun readFnKey(): Boolean = false
        override fun onCodePoint(codePoint: Int, ctrlDown: Boolean, session: TerminalSession): Boolean = false
        override fun onEmulatorSet() { terminalView?.requestFocus() }
        override fun logError(tag: String, message: String) = Unit
        override fun logWarn(tag: String, message: String) = Unit
        override fun logInfo(tag: String, message: String) = Unit
        override fun logDebug(tag: String, message: String) = Unit
        override fun logVerbose(tag: String, message: String) = Unit
        override fun logStackTraceWithMessage(tag: String, message: String, e: Exception) = Unit
        override fun logStackTrace(tag: String, e: Exception) = Unit
    }

    fun attach(view: TerminalView) {
        terminalView = view
        view.setTerminalViewClient(viewClient)
        view.setBackgroundColor(Color.rgb(3, 7, 5))
        view.setTypeface(Typeface.MONOSPACE)
        view.setTextSize(15)
        view.isFocusable = true
        view.isFocusableInTouchMode = true

        val activeSession = session?.takeIf { it.isRunning() } ?: run {
            session?.finishIfRunning()
            ProotAdapter(context, paths).createTerminalSession(sessionClient).also { session = it }
        }
        if (view.currentSession !== activeSession) view.attachSession(activeSession)
        view.requestFocus()
    }

    fun send(text: String) {
        val active = session ?: return
        val bytes = text.toByteArray(Charsets.UTF_8)
        active.write(bytes, 0, bytes.size)
    }

    fun restart() {
        session?.finishIfRunning()
        session = null
        terminalView?.let(::attach)
    }

    fun close() {
        session?.finishIfRunning()
        session = null
        terminalView = null
    }
}
