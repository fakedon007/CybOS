# Third-party notices

## Termux terminal-view and terminal-emulator

CybX Mobile 0.4.0 uses the published `com.termux.termux-app:terminal-view:0.118.0` library, which brings in the matching `terminal-emulator` module. These two terminal libraries are licensed under Apache License 2.0 according to the Termux project maintainers and upstream repository notices.

- Upstream: https://github.com/termux/termux-app
- Termux Libraries integration guide: https://github.com/termux/termux-app/wiki/Termux-Libraries
- License notice: https://github.com/termux/termux-app/blob/master/LICENSE.md

The Termux application's main app and other modules have separate license terms; CybX depends on only the terminal-view and terminal-emulator libraries. Review the upstream version's license notices before redistributing a modified copy.
