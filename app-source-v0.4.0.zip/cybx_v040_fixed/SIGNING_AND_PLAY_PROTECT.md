# Stable APK signing and Google Play Protect

## Why old APKs could not update in place

Earlier CybX Actions jobs generated debug signing keys on temporary GitHub runners. Different runner keys produce different APK signatures, so Android correctly rejects the new APK as an update. The first 0.4.0 installation must replace the older debug-signed build once. Do not expect an APK signed by a new key to update an app signed by an older temporary key.

## Permanent signing key for future updates

Do not commit a private keystore to this public repository. Create one release keystore and keep a secure backup. Add these GitHub repository Actions secrets (Settings → Secrets and variables → Actions → New repository secret):

- `CYBX_KEYSTORE_BASE64`: base64-encoded `.jks`/`.keystore` contents.
- `CYBX_KEY_ALIAS`: alias inside the keystore.
- `CYBX_KEYSTORE_PASSWORD`: keystore password.
- `CYBX_KEY_PASSWORD`: private-key password.

The workflow decodes the keystore only on the runner and signs the release APK. Keep the same key for every future release. Losing it means users cannot update an installed build in place. Never publish or commit the keystore or passwords.

A Windows example to create a new key (run once in a trusted local terminal):

```powershell
keytool -genkeypair -v -keystore cybx-release.jks -alias cybx-release -keyalg RSA -keysize 4096 -validity 10000
[Convert]::ToBase64String([IO.File]::ReadAllBytes("cybx-release.jks")) | Set-Clipboard
```

Paste the base64 output into `CYBX_KEYSTORE_BASE64`, and use the same alias/password values in the other secrets. Keep `cybx-release.jks` and passwords in a secure backup. Do not send them in chat or commit them to GitHub.

## Play Protect

CybX requests only INTERNET and ACCESS_NETWORK_STATE. It does not request SMS, Accessibility, notification-listener, or device-admin permissions. This reduces avoidable risk but cannot guarantee that Play Protect will never show a warning.

Play Protect may show an “App scan recommended” / “unknown app” message for apps installed from a browser or file manager because it has not seen that exact APK before. Allowing the scan is the supported path. If Google explicitly classifies or blocks a release as harmful and you believe this is a false positive, use Google's developer appeal process after reviewing its warning guidance:

https://developers.google.com/android/play-protect/warning-dev-guidance

Do not disable or bypass Play Protect. A stable signature helps users identify consistent updates; it does not by itself make an app Play Protect-approved.
