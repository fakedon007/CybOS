CybX Mobile 0.3.1 — Android ARM64 rootless app source

Changes from 0.3.0:
- Rootfs extractor accepts only safe archive-internal hard links to previously extracted regular files; this is needed for the official Kali NetHunter ARM64 minimal rootfs archive.
- PRoot commands use -0 to map the app user to guest root inside PRoot. This does NOT grant Android root.
- Version code 4 / version name 0.3.1.

Runtime bundle:
Use the companion CybX-ARM64-Runtime-Bundle.zip. Verify both SHA-256 hashes from its SHA256SUMS.txt before importing. Import the Android ARM64 proot binary first, then the Kali NetHunter minimal ARM64 rootfs tar.xz.

Limitations:
- Rootless PRoot shares the Android host kernel. It is not a separate booted Linux kernel.
- Terminal is command-per-process, not a PTY; interactive full-screen programs, persistent shell state, resizing, and job control are not provided.
- Android kernel and SELinux policy may restrict parts of Linux functionality.
- Use security tools only on networks and systems you own or are authorized to assess.
