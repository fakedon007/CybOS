CybX Mobile 0.3.2 — Android ARM64 rootless app source

Changes from 0.3.0:
- Supports safe archive-internal hard links to previously extracted regular files. The official Kali NetHunter ARM64 minimal archive contains six such links.
- Requires a supplied SHA-256 for both the PRoot binary and the Kali rootfs archive before importing.
- PRoot invocation follows the Kali NetHunter rootless launcher pattern: --link2symlink, -0, a /root working directory and a private /dev/shm bind.
- PRoot guest root is emulated only; this does not grant Android root.
- Version code 5 / version name 0.3.2.

Build:
Upload this ZIP to the GitHub repository as app-source.zip (replace the previous source archive). The repository's GitHub Actions workflow extracts it and runs :app:assembleDebug.

Runtime:
Use the companion CybX-ARM64-Runtime-Bundle.zip. Verify both hashes in SHA256SUMS.txt. Import PRoot first, then the Kali NetHunter minimal ARM64 rootfs.

Limitations:
- PRoot shares the Android host kernel; it is not a separate booted Linux kernel.
- The terminal is command-per-process, not a PTY. Persistent shell state, full-screen terminal apps, resize and job control are not implemented.
- Android kernel and SELinux policy can restrict Linux functionality.
- Use security tools only on systems and networks you own or are authorized to assess.
