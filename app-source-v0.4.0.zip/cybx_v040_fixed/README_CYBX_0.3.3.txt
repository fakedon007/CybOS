CybX Mobile 0.3.3 — Android ARM64 rootless app source

Fix for Android 10+ PRoot execution: Android blocks execve() on writable app-private filesDir (W^X / SELinux policy). PRoot is now packaged as app/src/main/jniLibs/arm64-v8a/libproot.so and Android is instructed to extract native libraries into the package-managed nativeLibraryDir (android:extractNativeLibs=true; legacy native lib packaging). ProotAdapter launches that read-only /data/app native library rather than a copied executable in filesDir.

Changes:
- PRoot binary bundled within the APK under the arm64-v8a native library directory.
- Removed the unsafe/ineffective PRoot import to writable filesDir.
- Linux Setup reports the bundled PRoot status and only asks the user to import the Kali rootfs archive.
- ABI filter is arm64-v8a (target device architecture).
- Version code 6 / version name 0.3.3.
- Keeps SHA-256 verification and guarded tar extraction for Kali NetHunter ARM64 minimal rootfs.

Build: GitHub Actions extracts this source archive and runs :app:assembleDebug.

Runtime: open Linux Setup, paste the rootfs SHA-256 from the matching CybX Runtime Bundle, choose kali-nethunter-rootfs-minimal-arm64.tar.xz, and wait for extraction. PRoot no longer needs to be imported separately.

Limitations: rootless Linux shares the Android host kernel; it is not a bootable separate OS or Android root. The terminal is currently command-per-process, not a persistent PTY.
