# CybX Mobile 0.4.0

CybX Mobile is a rootless Android ARM64 Linux workstation prototype. It runs a Kali NetHunter Minimal ARM64 userspace through an Android ARM64 PRoot executable and uses the Android host kernel. It is not a bootable replacement OS and does not grant Android root.

## Changes in 0.4.0

1. Rootfs selection no longer asks the user to paste a SHA-256. The app hashes the selected archive automatically and compares it with the pinned digest for the official Kali NetHunter Minimal ARM64 rootfs used by CybX Runtime Bundle v1.0.
2. Added CybX launcher branding and adaptive/round launcher icons.
3. Rootfs readiness now checks `/etc/os-release`, `env`, and `bash`, instead of only checking the release file. Extraction is staged and activated with rollback to the prior rootfs if activation fails.
4. Replaced one-command-per-process output with Termux's Apache-2.0 terminal-view and terminal-emulator libraries. The terminal uses a PTY, persistent interactive Bash process, VT/ANSI emulation, resize support, clipboard hooks, and extra-key buttons. Shell state (for example `cd`) persists while the app process/session remains alive. Android may still reclaim background processes; a dedicated foreground service/session manager is a future hardening step.
5. Added release-signing configuration driven by GitHub Actions secrets. Debug builds are not a stable update channel; see `SIGNING_AND_PLAY_PROTECT.md`.
6. Kept permissions minimal: INTERNET and ACCESS_NETWORK_STATE only. No SMS, accessibility-service, notification-listener, or device-admin permissions are requested.

## Runtime setup

1. Download and extract `CybX-ARM64-Runtime-Bundle-v1.0.zip`.
2. In CybX Mobile, open Linux Setup and select `kali-nethunter-rootfs-minimal-arm64.tar.xz`.
3. CybX calculates SHA-256 automatically. Only the pinned official archive is accepted. The app then validates the rootfs layout and activates it.
4. Open Terminal. Try `uname -m`, `cat /etc/os-release`, `pwd`, `cd /tmp`, and `pwd`.

The rootfs is app-private. Uninstalling CybX removes it, so keep the original `.tar.xz` archive outside the app.

## Android W^X compatibility

The app currently uses target SDK 28 because Android's app-data executable restrictions affect PRoot guest binaries on modern Android. This follows the execution model currently used by Termux. The app is compiled against API 35. This target level is a technical compatibility choice for the rootless PRoot prototype, not a claim of Google Play submission compliance. A Play Store build needs a separately engineered modern target-SDK execution path and full device testing.

## Build

The GitHub Actions workflow builds `app-source-v0.4.0.zip`. Without a configured release keystore it creates a debug APK for testing. For repeatable in-place updates, configure the four GitHub Actions repository secrets documented in `SIGNING_AND_PLAY_PROTECT.md` and use the signed release APK. The first v0.4.0 install will still require replacing older builds if their ephemeral debug signing certificates differ.

## Limitations

- PRoot is user-space emulation and shares Android's kernel.
- Kernel features requiring root or device-specific kernel support (monitor mode, raw packet injection, gadget/HID, privileged networking) are not guaranteed.
- The terminal has a real PTY and VT emulator, but sessions are still owned by the app process; background service persistence and multi-session management are future items.
- Rootfs digest is pinned to the CybX Runtime Bundle v1.0 archive. A future official rootfs update must update the pinned digest deliberately.
- Checksum matching verifies exact bytes. It does not replace publisher provenance review or Android app signing.

## Third-party components

- PRoot portable Android ARM64 binary: packaged from the existing CybX runtime bundle with upstream provenance noted in that bundle.
- Termux `terminal-view` and `terminal-emulator` 0.118.0: Apache License 2.0. Upstream source: https://github.com/termux/termux-app
