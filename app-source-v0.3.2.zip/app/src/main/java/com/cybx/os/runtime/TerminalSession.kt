package com.cybx.os.runtime

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.BufferedReader
import java.io.File
import java.io.InputStreamReader

/**
 * Command session adapter. This is a pipe-based shell, not a PTY:
 * interactive full-screen apps, terminal resize and job control need a PTY backend.
 */
class TerminalSession(private val paths: CybxPaths) {
    private var process: Process? = null

    fun start(): Process {
        check(process == null || process?.isAlive == false) { "A terminal session is already running" }
        val proot = ProotAdapter(paths)
        val p = proot.startInteractiveShell()
        process = p
        return p
    }

    suspend fun runOne(command: String, onLine: (String) -> Unit): Int =
        withContext(Dispatchers.IO) {
            require(command.length <= 4096) { "Command is too long" }
            require(!command.contains('\u0000')) { "Invalid command" }
            val p = ProcessBuilder(
                ProotAdapter(paths).buildShellCommand(command)
            ).directory(paths.base).redirectErrorStream(true).start()
            BufferedReader(InputStreamReader(p.inputStream)).useLines { lines ->
                lines.forEach(onLine)
            }
            p.waitFor()
        }

    fun stop() {
        process?.destroy()
        if (process?.isAlive == true) process?.destroyForcibly()
        process = null
    }
}
