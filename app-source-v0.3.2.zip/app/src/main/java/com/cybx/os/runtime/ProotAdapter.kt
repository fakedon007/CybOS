package com.cybx.os.runtime

import java.io.File

/** Runs the separately imported Android ARM64 PRoot binary inside the app-private sandbox. */
class ProotAdapter(private val paths: CybxPaths) {
    private val executable = File(paths.bin, "proot")

    fun isAvailable(): Boolean = executable.isFile && executable.canExecute()

    fun buildShellCommand(command: String): List<String> {
        require(isAvailable()) { "PRoot runtime is not installed. Import the ARM64 PRoot binary from the runtime bundle." }
        require(paths.rootfs.isDirectory) { "Kali rootfs is not installed." }
        return listOf(
            executable.absolutePath,
            "--link2symlink",
            "-0", // Guest root only; this does not grant Android root.
            "-r", paths.rootfs.absolutePath,
            "-b", "/dev",
            "-b", "/proc",
            "-b", "/sys",
            "-b", "${paths.rootHome.absolutePath}:/dev/shm",
            "-w", "/root",
            "/usr/bin/env", "-i",
            "HOME=/root", "USER=root", "TERM=xterm-256color",
            "PATH=/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin",
            "/bin/bash", "-lc", command
        )
    }

    fun buildInteractiveShellCommand(): List<String> {
        require(isAvailable()) { "PRoot runtime is not installed. Import the ARM64 PRoot binary first." }
        require(paths.rootfs.isDirectory) { "CybX Linux rootfs is not installed." }
        return listOf(
            executable.absolutePath,
            "--link2symlink",
            "-0", // Guest root only; this does not grant Android root.
            "-r", paths.rootfs.absolutePath,
            "-b", "/dev", "-b", "/proc", "-b", "/sys",
            "-b", "${paths.rootHome.absolutePath}:/dev/shm",
            "-w", "/root",
            "/usr/bin/env", "-i",
            "HOME=/root", "USER=root", "LOGNAME=root",
            "LANG=C.UTF-8", "TERM=xterm-256color",
            "PATH=/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin",
            "/bin/bash", "--noprofile", "--norc", "-i"
        )
    }

    fun processBuilder(command: List<String>): ProcessBuilder =
        ProcessBuilder(command).apply {
            directory(paths.rootfs)
            redirectErrorStream(true)
            // Portable Android PRoot cannot use the host's /tmp on stock Android.
            environment()["PROOT_TMP_DIR"] = paths.prootTmp.absolutePath
            environment()["TMPDIR"] = paths.prootTmp.absolutePath
            environment()["HOME"] = paths.rootHome.absolutePath
        }

    fun startInteractiveShell(): Process = processBuilder(buildInteractiveShellCommand()).start()
}
