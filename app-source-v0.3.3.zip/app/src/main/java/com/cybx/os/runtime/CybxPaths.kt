package com.cybx.os.runtime

import android.content.Context
import java.io.File

class CybxPaths(context: Context) {
    val base = File(context.filesDir, "cybx").apply { mkdirs() }
    // Android extracts APK-packaged native libraries under the read-only /data/app path.
    // Android 10+ blocks execve() from writable app-private filesDir (W^X policy).
    val prootExecutable = File(context.applicationInfo.nativeLibraryDir, "libproot.so")
    val rootfs = File(base, "rootfs")
    val downloads = File(base, "downloads").apply { mkdirs() }
    val bin = File(base, "bin").apply { mkdirs() }
    val logs = File(base, "logs").apply { mkdirs() }
    val prootTmp = File(base, "proot-tmp").apply { mkdirs() }
    val rootHome = File(base, "home-root").apply { mkdirs() }
    val rootfsArchive = File(downloads, "cybx-kali-arm64-rootfs.tar.xz")
}
