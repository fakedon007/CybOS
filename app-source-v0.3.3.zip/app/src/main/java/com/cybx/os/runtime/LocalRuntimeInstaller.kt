package com.cybx.os.runtime

import android.content.Context
import android.net.Uri
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File
import java.security.MessageDigest

class LocalRuntimeInstaller(context: Context) {
    private val appContext = context.applicationContext
    private val paths = CybxPaths(appContext)
    private val extractor = SafeRootfsExtractor()

    suspend fun importRootfs(uri: Uri, expectedSha256: String, onProgress: (String) -> Unit) =
        withContext(Dispatchers.IO) {
            require(expectedSha256.matches(Regex("^[A-Fa-f0-9]{64}$"))) { "Enter a valid 64-character SHA-256" }
            paths.downloads.mkdirs()
            val temp = File(paths.downloads, "rootfs-import.part")
            appContext.contentResolver.openInputStream(uri)?.use { input ->
                temp.outputStream().buffered().use { output ->
                    val buffer = ByteArray(128 * 1024)
                    while (true) {
                        val n = input.read(buffer)
                        if (n < 0) break
                        output.write(buffer, 0, n)
                    }
                }
            } ?: error("Cannot read selected rootfs archive")
            onProgress("Verifying SHA-256…")
            val digest = MessageDigest.getInstance("SHA-256")
            temp.inputStream().buffered().use { input ->
                val buf = ByteArray(128 * 1024)
                while (true) { val n = input.read(buf); if (n < 0) break; digest.update(buf, 0, n) }
            }
            val actual = digest.digest().joinToString("") { "%02x".format(it) }
            require(actual.equals(expectedSha256, ignoreCase = true)) { "SHA-256 mismatch. Import cancelled." }
            onProgress("Extracting rootfs…")
            val staging = File(paths.base, "rootfs.import-staging")
            val ready = File(paths.base, "rootfs.import-ready")
            if (staging.exists()) check(staging.deleteRecursively()) { "Cannot clear old extraction staging" }
            if (ready.exists()) check(ready.deleteRecursively()) { "Cannot clear old rootfs staging" }
            extractor.extractTarXz(temp, staging)

            // Official NetHunter rootfs archives contain a single top-level directory
            // (e.g. kali-arm64/). Also accept archives that already have rootfs entries
            // at archive root.
            val candidates = buildList {
                if (File(staging, "etc/os-release").isFile) add(staging)
                staging.listFiles()?.filter { it.isDirectory }?.forEach { child ->
                    if (File(child, "etc/os-release").isFile) add(child)
                }
            }
            require(candidates.size == 1) { "Archive must contain exactly one Linux rootfs with etc/os-release" }
            val candidate = candidates.single()
            val hasBash = File(candidate, "bin/bash").exists() || File(candidate, "usr/bin/bash").exists()
            require(hasBash) { "Archive is missing bash; this is not a usable ARM64 Linux rootfs" }

            if (candidate == staging) {
                check(staging.renameTo(ready)) { "Could not prepare rootfs directory" }
            } else {
                check(candidate.renameTo(ready)) { "Could not promote rootfs directory" }
                check(staging.deleteRecursively()) { "Could not clean extraction wrapper" }
            }
            listOf("dev", "proc", "sys", "tmp", "root", "run").forEach { File(ready, it).mkdirs() }

            val existing = paths.rootfs
            if (existing.exists()) check(existing.deleteRecursively()) { "Cannot replace existing rootfs" }
            check(ready.renameTo(existing)) { "Could not activate rootfs" }
            temp.delete()
            onProgress("CybX Linux environment installed")
        }

}
