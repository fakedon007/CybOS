package com.cybx.os.runtime


/** Runs the APK-packaged Android ARM64 PRoot binary from nativeLibraryDir. */
class ProotAdapter(private val paths: CybxPaths) {
    // Must execute from PackageManager-extracted nativeLibraryDir, not filesDir.
    // Android 10+ SELinux/W^X policy denies execve() on writable app data files.
    private val executable = paths.prootExecutable

    fun isAvailable(): Boolean = executable.isFile && executable.canExecute() && executable.length() > 0

    fun buildShellCommand(command: String): List<String> {
        require(isAvailable()) { "Bundled Android ARM64 PRoot is missing. Reinstall the CybX APK." }
        require(paths.rootfs.isDirectory) { "Kali rootfs is not installed." }
        return listOf(
            executable.absolutePath,
            "--link2symlink",
            "-0", // Guest root only; this does not grant Android root.
            "-r", paths.rootfs.absolutePath,
            "-b", "/dev",
            "-b", "/proc",
            "-b", "/sys",
            "-b", "${paths.rootHome.absolutePath}:/dev/shm",
            "-w", "/root",
            "/usr/bin/env", "-i",
            "HOME=/root", "USER=root", "TERM=xterm-256color",
            "PATH=/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin",
            "/bin/bash", "-lc", command
        )
    }

    fun buildInteractiveShellCommand(): List<String> {
        require(isAvailable()) { "Bundled Android ARM64 PRoot is missing. Reinstall the CybX APK." }
        require(paths.rootfs.isDirectory) { "CybX Linux rootfs is not installed." }
        return listOf(
            executable.absolutePath,
            "--link2symlink",
            "-0", // Guest root only; this does not grant Android root.
            "-r", paths.rootfs.absolutePath,
            "-b", "/dev", "-b", "/proc", "-b", "/sys",
            "-b", "${paths.rootHome.absolutePath}:/dev/shm",
            "-w", "/root",
            "/usr/bin/env", "-i",
            "HOME=/root", "USER=root", "LOGNAME=root",
            "LANG=C.UTF-8", "TERM=xterm-256color",
            "PATH=/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin",
            "/bin/bash", "--noprofile", "--norc", "-i"
        )
    }

    fun processBuilder(command: List<String>): ProcessBuilder =
        ProcessBuilder(command).apply {
            directory(paths.rootfs)
            redirectErrorStream(true)
            // Portable Android PRoot cannot use the host's /tmp on stock Android.
            environment()["PROOT_TMP_DIR"] = paths.prootTmp.absolutePath
            environment()["TMPDIR"] = paths.prootTmp.absolutePath
            environment()["HOME"] = paths.rootHome.absolutePath
        }

    fun startInteractiveShell(): Process = processBuilder(buildInteractiveShellCommand()).start()
}
