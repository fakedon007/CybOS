# CybX Mobile 0.4.1 — startup crash fix

## Fix

The Compose UI was attempting to render `@mipmap/ic_launcher` with `painterResource()`. That mipmap is an Android `AdaptiveIconDrawable`, while Compose `painterResource()` supports bitmap/vector drawable resources, not adaptive-icon drawables. Since the reference was used in the top app bar, it could crash on the first screen render.

Both Compose image references now use `@drawable/ic_launcher_foreground`, which is a VectorDrawable. The adaptive launcher icon remains configured in `AndroidManifest.xml` for the Android launcher.

## Version

- `applicationId`: `com.cybx.os` (unchanged)
- `versionCode`: `10`
- `versionName`: `0.4.1`

## Build

Open this project folder in Android Studio, allow Gradle sync, then select **Build → Build Bundle(s) / APK(s) → Build APK(s)**. The debug APK is normally produced at `app/build/outputs/apk/debug/app-debug.apk`.

Install over the existing app only when the APK is signed with the same signing key. If Android reports a signature conflict, the existing app must be uninstalled before installing this build; uninstalling removes app-private Kali rootfs data, so back up the original rootfs archive first.

## Verification status

The source-level startup crash cause was corrected. This container does not have Android SDK/Gradle build tooling configured, so an APK could not be compiled or device-tested here.
